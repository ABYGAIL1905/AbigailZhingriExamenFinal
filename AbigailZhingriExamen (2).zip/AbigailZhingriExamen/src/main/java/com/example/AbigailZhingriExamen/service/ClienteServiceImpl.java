/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.service;

import com.example.AbigailZhingriExamen.modelo.Cliente;
import com.example.AbigailZhingriExamen.repositorio.ClienteRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

/**
 *
 * @author PC01
 */
@Service
public class ClienteServiceImpl extends GenericServiceImpl<Cliente, Long> implements IClienteService{

	@Autowired
    ClienteRep crep;
    @Override
    public CrudRepository<Cliente, Long> getDao() {
        return crep;
    }
    
}
