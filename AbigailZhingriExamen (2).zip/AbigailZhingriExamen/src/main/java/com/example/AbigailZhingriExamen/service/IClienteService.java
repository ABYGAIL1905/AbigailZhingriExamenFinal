/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.service;

import com.example.AbigailZhingriExamen.modelo.Cliente;

/**
 *
 * @author PC01
 */
public interface IClienteService extends GenericService<Cliente, Long>{
    
}
