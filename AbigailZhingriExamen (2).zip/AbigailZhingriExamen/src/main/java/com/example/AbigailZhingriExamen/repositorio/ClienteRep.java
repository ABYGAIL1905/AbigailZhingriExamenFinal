/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.repositorio;

import com.example.AbigailZhingriExamen.modelo.Cliente;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 *
 * @author PC01
 */
public interface ClienteRep extends  MongoRepository<Cliente, Long>{
    
}
