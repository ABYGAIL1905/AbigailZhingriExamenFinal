/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.service;

import com.example.AbigailZhingriExamen.modelo.Plato;
import com.example.AbigailZhingriExamen.repositorio.PlatoRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author PC01
 */
public class PlatoServiceImpl extends GenericServiceImpl<Plato, Long> implements IPlatoService{
@Autowired
    PlatoRep plrep;
    @Override
    public CrudRepository<Plato, Long> getDao() {
       return plrep;
    }
    
}
