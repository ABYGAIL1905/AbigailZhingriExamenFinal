/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.service;

import com.example.AbigailZhingriExamen.modelo.Restaurante;
import com.example.AbigailZhingriExamen.repositorio.RestauranteRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author PC01
 */
public class RestauranteServiceImpl extends GenericServiceImpl<Restaurante, Long> implements IRestauranteService{
    @Autowired
    RestauranteRep r_rep;

    @Override
    public CrudRepository<Restaurante, Long> getDao() {
       return r_rep;
    }
    
}
