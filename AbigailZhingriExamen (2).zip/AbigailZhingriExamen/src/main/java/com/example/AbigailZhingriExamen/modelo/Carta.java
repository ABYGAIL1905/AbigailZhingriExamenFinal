/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.modelo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author PC01
 */
@Getter
@Setter
@Document(collection = "Carta")
@Data
public class Carta {
    @Id
    private String nombre_ca;
    private String categoria_ca;
   private int cantidad; 
   Plato plato;
}
