/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.modelo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author PC01
 */
@Getter
@Setter
@Document(collection = "Restaurante")
@Data
public class Restaurante {
    @Id
   private Long id_restaurante;
     private String nombre_r;
    private String correo_r;
    private String direccion_r;
   private  String telefono_r;
   Cliente cliente;
   Carta carta;
     
    
}
