/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.service;

import com.example.AbigailZhingriExamen.modelo.Carta;
import com.example.AbigailZhingriExamen.repositorio.CartaRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author PC01
 */
public class CartaServiceImpl extends GenericServiceImpl<Carta, Long> implements ICartaService{
@Autowired
    CartaRep car_rep;
    @Override
    public CrudRepository<Carta, Long> getDao() {
     return car_rep;
    }
    
}
