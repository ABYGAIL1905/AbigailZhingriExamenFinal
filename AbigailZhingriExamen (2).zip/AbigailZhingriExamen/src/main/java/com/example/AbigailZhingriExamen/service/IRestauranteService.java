/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.AbigailZhingriExamen.service;

import com.example.AbigailZhingriExamen.modelo.Cliente;
import com.example.AbigailZhingriExamen.modelo.Restaurante;

/**
 *
 * @author PC01
 */
public interface IRestauranteService extends GenericService<Restaurante, Long>{
    
}
